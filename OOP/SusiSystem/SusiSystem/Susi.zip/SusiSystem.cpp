#include <iostream>
#include "Functions.h"
#include "Course.h"
#include "Student.h"
#include "Line.h"
#include "Susi.h"
#include "Visitor.h"
#include "Serialize.h"

std::ostream& operator<<(std::ostream& out, Susi& s) {
	Serialize serializer(out);
	s.accept(&serializer);
	return out;
}

std::istream& operator>>(std::istream& input, Susi& susi) {
	std::string line;
	std::getline(input, line);
	trim(line);
	std::vector<std::string> attr = split(line, "|");
	std::cout << attr.size() << '\n';
	if (attr.size() < 3 && attr.size() != 1)
		throw std::runtime_error("The file is corrupted!-");
	if (attr.size() != 1) {
		size_t programs = toInt(attr[0]), students = toInt(attr[1]);
		int fn = toInt(attr[2]);

		susi._fn = fn;

		for (size_t i = 0; i < programs; i++) {
			susi.addProgram(getProgramInput(input));
			break;
		}
	}
	return input;
}

int main()
{
	std::ifstream fileIn("test2.txt", std::ios::in);

	try {
		Susi mySusi(1000);

		//fileIn >> mySusi;

		/*mySusi.addProgram("KN", 5);
		mySusi.addProgram("SI", 4);
		mySusi.addProgram("TU", 4);
		//std::cout << "programs ->" << mySusi.getProgramsLen() << std::endl;
		//std::cout << (++mySusi.getPrograms().begin() == mySusi.getPrograms().end()) << '\n';

		/*for (Program* x : mySusi.getPrograms()) {
			std::cout << x->getName() << '\n';
		}*/

		/*mySusi.addCourseToProgram("", 0);
		mySusi.addSubjectToCourseOfProgram("", 0, "Matematika");
		mySusi.addStudentToProgram("KN", "Hristo", 2);
		mySusi.addSubjectToCourseOfProgram("KN", 0, "Matematika2");
		mySusi.addStudentToProgram("KN", "Dimitar", 2);
		mySusi.addCourseToProgram("KN", 0);
		mySusi.addCourseToProgram("", 1);
		mySusi.addSubjectToCourseOfProgram("", 1, "Angliiskiezik1");
		mySusi.addSubjectToCourseOfProgram("KN", 1, "Angliiskiezik2");
		mySusi.addStudentToProgram("KN", "Ivan", 2);
		mySusi.addGradeToStudents(5.3);
		mySusi.transferStudent(1000, "SI", 3);
		mySusi.advanceStudents();*/

		//std::cout << mySusi;

		//mySusi.print(1000);
		//mySusi.print(-1, "KN");
		//mySusi.print(-1, "", 1);

		for (Line newCommand : std::cin | Line()) {
			try {
				newCommand.execute(&mySusi);
			}
			catch (const std::runtime_error& error) {
				std::cout << error.what() << "\n";
			}
		}

		/*Program kn("KN", 1000, 5);
		kn.createCourse(1);
		kn.addSubjectToCourse("Lineina algebra", 0);
		kn.addSubjectToCourse("Vissha algebra", 0);
		//kn.addSubjectToCourse("Uvod v programiraneto", 0);
		kn.createCourse(2);
		kn.addSubjectToCourse("Vissha algebra 2", 1);
		kn.signStudent("Hristo", 1);
		kn.signStudent("Hristo", 1);
		kn.signStudent("Hristo", 2);
		kn.signStudent("Hristo", 3);
		kn.signStudent("Hristo", 3);
		kn.signStudent("Hristo", 3);

		std::cout << " \n\n";
		kn.doStudents(&Student::advanceCourse, id);
		kn.doStudents(&Student::interuptStudent, id);
		std::cout << " \n\n";*/

	}
	catch (const std::runtime_error& error) {
		std::cout << error.what() << "\n";
	}
}
